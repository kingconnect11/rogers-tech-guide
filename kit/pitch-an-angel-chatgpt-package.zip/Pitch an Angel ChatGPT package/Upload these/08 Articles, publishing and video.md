# 08 Articles, publishing and video

Roger writes articles for the Resources section of pitchanangel.com and publishes them himself. Once a month he also records short clips for LinkedIn. This file covers both.

## What you do for articles

1. **Write it.** When Roger has talked through one founder question and says "article prompt", turn what he said into an article, following "Turning a talk into an article" below.
2. **Make the publishing ZIP** when Roger approves the article: one ZIP called "Article N publishing package.zip" that follows "The publishing package" below exactly, with article-content.html, seo-settings.json and an assets folder with the images. Then tell Roger: "Your ZIP is ready. Go to pitchanangel.com/admin, sign in, click Articles, choose this ZIP, check the preview and press Publish."
3. **Fix problems.** If Roger pastes back a list of problems from the Articles page, fix exactly those problems and make a new ZIP. Do not change the article's wording unless he asks.
4. **Write the LinkedIn post** after he publishes, using "The LinkedIn post" below, with the live link.
5. **Roger's publishing guide.** If this project has no file called "Roger's publishing guide", offer to make one the first time Roger asks about publishing, following "Roger's user guide" below. Give it as a Word document he can print, and ask him to add it to the project's files.

## Turning a talk into an article

When Roger has talked through one founder question for 10 to 15 minutes and says "article prompt", turn what he said into an article for pitchanangel.com in his voice:

- Title: the question a founder would type into Google, under 60 characters. Answer it in the first paragraph.
- Four to six headings, each a follow-up question. 900 to 1,600 words.
- Keep his story from the room; remove any founder or company names.
- End with who this is for and an invitation to book at pitchanangel.com/contact. No promises of investment. No long dashes.
- Then give him a 150-character search summary, three other titles, and a LinkedIn post that links to the article.

When he approves it, make the publishing ZIP described below. Roger publishes it himself at pitchanangel.com/admin.

Topics Roger has proposed, in order: the first 30 seconds (published), you are pitching investors, not selling the product; traction, what actually counts; what the funding request buys; handling investor questions.

## How Roger publishes (no one else needed)

1. Open **pitchanangel.com/admin** and type roger@bayangels.com. The page is headed "Pitch requests, ready for review"; that is the right place. Click the link in the email that arrives.
2. Click **Articles** at the top.
3. Under "Publish a new article," choose the ZIP.
4. Read the preview. It shows the page exactly as visitors will see it. Nothing is live yet.
5. Press **Publish**. The article is live at once. The Resources page and the homepage pick it up within a minute.

If something in the ZIP needs fixing, the page lists each problem in a sentence and has a button, "Copy these notes for ChatGPT." Paste those notes into ChatGPT and upload the new ZIP it makes.

Uploading a new ZIP with the same page address replaces that article and keeps its original date. That is how to correct a typo after publishing. The **Take down** button turns a live article back into a draft.

---

## Roger's user guide

A short guide for Roger himself, written by you, titled "Roger's publishing guide". Make it once, then update it only if this file changes.

- One or two pages, large clear type, numbered steps, no technical words. Write to Roger as "you".
- Cover, in this order:
  1. Writing an article with ChatGPT and asking for the publishing ZIP when he is happy with it.
  2. Saving the ZIP to his computer and knowing where it went (usually Downloads).
  3. Signing in at pitchanangel.com/admin with roger@bayangels.com and the emailed link. The link works once and expires, so ask for a new one if it has been a while.
  4. Clicking Articles, choosing the ZIP, reading the preview, and pressing Publish.
  5. What to do if the page lists problems: press "Copy these notes for ChatGPT", paste them here, upload the new ZIP.
  6. Fixing a typo after publishing: ask ChatGPT for a corrected ZIP and upload it. Same address, same date.
  7. Taking an article down with Take down, and putting it back with Publish.
  8. Asking ChatGPT for the LinkedIn post once the article is live.
  9. Who to email if he is stuck: philip@bayangels.com, with a screenshot.
- End with a short checklist he can tick before pressing Publish: title right, pictures showing, links work, closing invitation present.

---

## The publishing package

One ZIP. Other files in it, such as the Word copy, a preview page or a handoff note, are fine and are ignored.

### 1. article-content.html

The article as plain HTML. Use only these pieces:

| What | HTML |
|---|---|
| Title block (optional, the site makes its own) | `<header>...</header>` |
| Main image, at the very top | `<figure class="hero"><img src="assets/NAME.jpg" width="1536" height="1024" alt="DESCRIPTION"><figcaption>CAPTION</figcaption></figure>` |
| Paragraph | `<p>...</p>` |
| Section heading | `<h2>...</h2>` (these become the "In this article" list, numbered 01, 02 and so on) |
| Smaller heading inside a section | `<h3>...</h3>` |
| Highlighted line repeated from the text | `<p class="extract">...</p>` |
| Example set apart in a box | `<p class="example">...</p>` |
| The better example in a before and after pair | `<p class="example-clear">...</p>` |
| Numbered step diagram | `<figure class="opening"><ol class="steps"><li><strong>Step title</strong><span>Question</span></li>...</ol><figcaption>Caption</figcaption></figure>` |
| Other image | `<figure class="image"><img src="assets/NAME.jpg" alt="DESCRIPTION"><figcaption>CAPTION</figcaption></figure>` |
| Lists, bold, italics, links | `<ul>`, `<ol>`, `<li>`, `<strong>`, `<em>`, `<a href="...">` |

Anything else (styles, scripts, tables, embedded video, other classes) is removed when the page is shown. Don't add Roger's photo. The site already shows it in the bio box under every article.

**Links:**
- Article 1: https://www.pitchanangel.com/resources/startup-pitch-timing
- Article 2: https://www.pitchanangel.com/resources/first-thirty-seconds-startup-pitch
- The closing coaching invitation links to **https://www.pitchanangel.com/contact**, as in articles 1 and 2. For example: `visit <a href="https://www.pitchanangel.com/contact">PitchanAngel.com</a> to arrange a conversation with me.`
- Links to other websites open in a new tab automatically.

### 2. seo-settings.json

```json
{
  "article_number": 3,
  "headline": "The article title exactly as it appears on the page",
  "seo_title": "Search title under 60 characters | Roger King",
  "description": "One or two sentences, under 160 characters, for Google and link previews.",
  "standfirst": "One sentence shown under the title. Optional.",
  "suggested_path": "/resources/three-to-six-words-of-topic",
  "share_image": "assets/article-3-share.jpg",
  "keywords": ["main search phrase", "second phrase", "third phrase"]
}
```

- **article_number**: the next number in the series. Articles 1 and 2 are published, so the next is 3.
- **suggested_path**: lowercase letters, numbers and hyphens only, and it must not repeat an earlier article's address. It becomes pitchanangel.com/resources/...
- If **standfirst** is left out, the site uses the description, minus the title if the description starts with it.
- Leave out publication dates and full URLs. The site sets them when Roger presses Publish.

### 3. assets/

- **Main image**: JPG, about 1536 x 1024 or 1600 x 900 pixels.
- **Share image**: JPG, exactly 1200 x 630 pixels. LinkedIn shows it when the link is posted.
- **Any other images** the article uses.
- JPG, PNG or WebP only, each under 5 MB. No SVG.
- Every image named in the HTML or JSON must be in the ZIP, with the same name and folder.

---

## House style for the articles

These held for articles 1 and 2.

- Roger's own voice, first person, plain words, practical advice for founders.
- Teaching examples are invented and say so. No client stories, client names, fundraising results or testimonials unless Roger confirms the client agreed.
- A highlighted extract repeats a sentence from the article. It is not a new quotation.
- Each image gets a short description for screen readers. Illustrations are captioned as conceptual.
- End with the coaching invitation linked to the contact page.
- Plain punctuation. Avoid long dashes.

---

## The LinkedIn post

Write it after the article is live, with the real link. Use lines from the article itself, in this order:

1. The article's opening idea, in one or two sentences.
2. "In my [third] article for Pitch an Angel, I explain..." and the main point.
3. One practical takeaway from the article.
4. "Read the article: [live link]"
5. "If you would like feedback on your pitch, visit PitchanAngel.com to arrange a conversation with me."
6. One question for readers.
7. Three or four hashtags, such as #StartupPitch #AngelInvesting #PitchCoaching #Founders. (Article posts are the one exception to the no-hashtag habit in file 07.)

Before posting, paste the link into https://www.linkedin.com/post-inspector/ so LinkedIn shows the share image.

---

## If something goes wrong

- **The Articles page says publishing is not switched on yet:** that should not happen now; it was switched on 27 October 2026. Email philip@bayangels.com if it does.
- **The sign-in link does not work:** it works once and expires. Go back to pitchanangel.com/admin and ask for a new one.
- **The page lists problems with the ZIP:** paste the notes into ChatGPT and upload the new ZIP.
- **Anything else:** email philip@bayangels.com with a screenshot of the message on the page.

## Turning a recording into clips

Once a month Roger records six to eight answers of about a minute each, phone upright at eye level, facing a window. When he gives you the transcript:

> For each answer, give me the best 60 seconds with start and end times, a caption under 150 characters, and a LinkedIn post in my voice. Then suggest a posting schedule for the month, one or two a week.

Each clip follows four beats: a hook in the first 3 seconds (a question a founder asked, or one blunt line, never "Hi, I'm Roger"), one point and one story, one action to take, and "More at pitchanangel.com". Philip or an editing app cuts the clips and adds captions.

Before anything goes public: no founder, company or deck named without written permission; nothing that sounds like investment, introductions or Bay Angels access; would Roger say it to the founder's face; captions on and a link to pitchanangel.com.
