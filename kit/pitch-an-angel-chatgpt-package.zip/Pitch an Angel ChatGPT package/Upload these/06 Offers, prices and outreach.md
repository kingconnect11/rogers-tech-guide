# 06 Offers, prices and outreach

What Pitch an Angel sells, what to say about it, and how Roger turns conversations and offers into paid work. Who Roger is and how he works are in file 01.

## What Pitch an Angel sells

### Launch pricing (until 30 November 2026)

Every paid offer below has a launch price until 30 November and a higher price from 1 December. Founders who pay by 30 November keep the launch price, even if their sessions run into December. The date does not move.

What Roger says: "Until the end of November I am at my launch prices. If you pay by the 30th, you keep that price even if we meet in December."

Never describe the higher price as a "regular" or "normal" price the founder is saving against, and never offer to extend the date. Say what is true: the launch price, and the price from 1 December.

**From 1 December 2026, check today's date first.** The launch is over: quote only the "then" price for each offer (for example, Single Session $750), drop every mention of launch prices, including in the templates and the polite redirect below, and never offer the old price as a discount. A founder who paid by 30 November keeps the price they paid.

### Free

- **Articles and LinkedIn posts** by Roger.
- **A 15-minute fit call** to hear where a founder's raise stands and point to the right package. Not a coaching session. No charge.

### Booking

Pitch an Angel does not use Calendly any more. Unless Roger gives you a booking link to use, every invitation asks the founder to reply with two or three times that work for them, and Roger sends a Zoom link. Payment details come from Roger; never make up a payment link.

### Sessions with Roger

- **Single Session, $495 launch price (then $750).** 45 minutes live, a written report within 48 hours, and a 15-minute follow-up within six weeks. For a founder who wants a fast, honest read.
- **Three Sessions Sprint, $1,095 launch price (then $1,695).** Sessions of 45, 45 and 30 minutes over several weeks, a written report after each. For a founder with a pitch event or investor meetings coming who needs more than one pass. A Single Session bought in the last 30 days counts toward it (recommended by the October pricing report; confirm with Philip before offering it).
- **Comprehensive Review, $1,495 launch price (then $2,295).** An hour with Roger and his written report, Philip King's Strategy and Design Review of the deck, and a 45-minute follow-up with both.

### Deck work with Philip King

- **Deck Design Review, $395 launch price (then $595).** Slide by slide, with a written report.
- **Strategy and Design Review, $695 launch price (then $1,095).** The review plus an hour with Philip on the deck and the raise.
- **Deck Redesign, from $1,500 launch price (then from $2,400).** Philip rebuilds up to 15 slides.

### The Full Program, $4,500 launch price (then $6,900)

Pitch, deck and numbers in one program, six to eight weeks.

- Roger: four one-hour pitch sessions, a written report after each.
- Philip: a slide-by-slide deck review (design, energy and phrasing, PR view, today's angel market), a redesign of up to 15 slides with one revision, a session on the new deck, and a check-in.
- Michael DeBoard, fractional CFO: pricing strategy review, a health check of the books with a clean-up plan, and the structure of the raise (round size, instrument, use of funds, runway). Actual bookkeeping clean-up is quoted separately.
- To finish: a mock angel panel with Roger, Philip, Michael and George Parrish, with a scorecard from each.
- $4,500 is the launch price, until 30 November and for up to three founders. From 1 December it is $6,900. Half to start, half at the midpoint.
- Not included: legal, tax or securities advice, and introductions to investors.

### For accelerators, incubators, universities and small business centers (new)

- **Cohort pitch workshop, from $2,500 launch price (then from $3,900)** for up to 20 founders. Two hours, live on Zoom or in person in the Bay Area. Roger's five rules, three founders pitch live for feedback, and a workbook for every founder built from their own company.
- **Mock angel panel for demo day,** quoted per event.

### Coming soon (do not sell until Philip confirms)

- **Pitch Clinic,** a monthly live Zoom: six founders pitch for five minutes each and get feedback from Roger and a guest. About $149 to pitch, $49 to watch.
- **Recorded course** of eight short lessons with a personal workbook, about $149.
- **Raise Support,** $750 a month for founders who are actively raising.
- **AI Pitch Review, $49,** a written deck review at pitchanangel.com/coach by software trained on Roger's rules. Built; Philip opens it to the public. Until then Roger can run it free for his own clients (file 05).

### What Pitch an Angel never sells

- A fee or a percentage tied to money raised.
- Introductions to investors as part of a package.
- Anything that suggests a founder will be selected by, or pitch at, Bay Angels.

---

## Which offer fits which founder

- Raising in the next month, has a deck, wants an honest read: **Single Session.**
- Pitch event or investor meetings in the next six weeks, deck still changing: **Sprint.**
- Deck looks weak as well as the pitch: **Comprehensive Review**, or Single Session plus Philip's Strategy and Design Review.
- Serious raise, wants pitch, deck and financial structure all checked: **Full Program.**
- Idea stage, no raise planned: a kind note and an article link. Coaching pays off once a raise is on the calendar.
- An organization with a group of founders: **cohort workshop.**

---

## The 30-day test (for any new opportunity)

Roger gets offers: a success fee for finding an investor, shares in a company for advice, a big project with no money attached yet. Before Roger says yes, ask him these six questions, one at a time, and then give a verdict.

1. Will it put cash in the bank within 30 days?
2. Is the payment for work Roger controls (a session, a review, a workshop), not for something he cannot control (an investment closing, a sale happening)?
3. Is it paid in cash, not only in shares or a promise?
4. Can Roger explain the company and his role in two sentences?
5. Does it keep Pitch an Angel and Bay Angels clean (no fee for introducing investors, nothing that touches Bay Angels selection)?
6. Does it fit in the hours Roger has this week without pushing out a paying founder?

**Verdict:**

- All six yes: go ahead.
- No to question 2, 3 or 5: park it. Roger replies with the polite redirect below, and sends the offer to Philip, and any shares or numbers to Michael DeBoard, before saying anything more. Explain why in one sentence: success fees for raising money can break securities rules for unregistered people, and shares received for work are usually taxed as income when received even if they can never be sold. This is general information; a lawyer or an accountant gives the real answer.
- Any other no: not now. Put it on a list to revisit after 18 November.

**The polite redirect (turn a shiny object into paid work):**

> Thank you for thinking of me. I don't take fees tied to fundraising or to introductions, and I don't take shares for advice. What I do is help founders get their pitch ready for investors. If that would help you, the place to start is a Single Session ($495 at my launch price until the end of November), or the Full Program if you want your pitch, your deck and your numbers ready together. Happy to set up a short call.

---

## Message templates

Keep each under 120 words, in Roger's voice. Fill in the brackets. Never add a claim Roger did not give you.

**1. A past client**

> Hi [first name], how is the raise going? I have been thinking about [company] since our session. If you are heading into more meetings, I am happy to do a follow-up run-through. And if you know another founder getting ready to raise in the next few months, I would be glad to give them an honest read.

**2. Someone in Roger's network**

> Hi [first name], I am taking on a few founders this month who are getting ready to pitch angel investors. If you know someone raising in the next 90 days, I would be glad to give them an honest read on their pitch before they go in. They can start at pitchanangel.com, or just reply and I will reach out. Thank you.

**3. A founder Roger has met or judged**

> Hi [first name], I enjoyed hearing about [company] at [event]. If you are raising soon, I now coach founders one-on-one on the pitch itself: what lands with angels, what loses them, and how to handle the hard questions. Happy to talk for 15 minutes if it would help.

**4. An accelerator, incubator, university program or small business center**

> Hi [first name], I founded Bay Angels in 1997 and have heard hundreds of pitches since. I run a two-hour pitch workshop for founder cohorts: my five rules for an angel pitch, three founders pitching live for feedback, and a workbook for every founder built from their own company. Would it help your [spring cohort or demo day]? I would be glad to send a one-page outline and find a date.

**5. A current client, the next step**

> Hi [first name], good work on [what they improved]. The next thing that would move this forward is [the deck, the numbers, another run-through]. [Philip's Strategy and Design Review / a Sprint / the Full Program] covers exactly that. Your session counts toward it if you start this month. Want me to set it up?

**6. A founder who went quiet**

> Hi [first name], checking in on [company]. When is your next pitch? If timing has moved, no problem. When it is back on the calendar, I am here.

---

## The cohort workshop, run of show (two hours)

1. 0:00 to 0:10. Welcome. Why most pitches fail in the first 90 seconds.
2. 0:10 to 0:40. Roger's five rules: know the audience, create interest and earn the follow-up, connect the basics, deliver with command, the deck is support, not a crutch.
3. 0:40 to 0:55. Workbook exercise: rewrite your first 30 seconds. Three volunteers read theirs.
4. 0:55 to 1:40. Three founders pitch (five minutes each), Roger gives live feedback (eight minutes each), the room asks one question each.
5. 1:40 to 1:55. The ten questions angels always ask, and how to answer them short.
6. 1:55 to 2:00. Next steps, and how to book a one-on-one session.

## Recording a lesson

When Roger says "plan a recording on [topic]": give a ten-minute outline in five parts (the idea in one sentence, why it matters to an investor, one invented example clearly labeled as invented, the fix, one exercise), a list of five slides with titles, and a two-sentence closing that points to pitchanangel.com.

---

## Rules that never change

1. Never promise investment, introductions or any advantage in a selection process.
2. Never mention a Bay Angels pipeline, deal flow or selection. Bay Angels is Roger's background only.
3. No long dashes or double hyphens in anything a founder or reader sees.
4. Roger approves and sends everything.
5. No legal, tax or securities advice. Point to a lawyer, an accountant, or Michael DeBoard for numbers.
6. Written reports reach founders within 48 hours of a session.
