# 03 Prep packets and call worksheets

## TASK: Prep packet for [company]

Turns a founder's intake into a briefing Roger can read in three minutes, plus a recommendation on whether and how to move forward. Nothing in it promises investment or suggests coaching affects any investment decision.

Keep it scannable. Roger reads it right before he replies or right before the call.

1. **Snapshot.** Founder, company, one line on what they do, industry, stage, team size, full time or not. Round, raised to date, raising now, timeline. The offer they chose, or "not sure yet".
2. **Fit read.** A plain judgment: strong fit, workable fit, or weak fit, with one or two sentences of why.
   - Weak-fit signals: idea stage with no product and no urgency; no raise on the calendar and no pitch to work on; a request that is really graphic design rather than coaching.
3. **What they think the problem is.** Their stated help needs, in Roger's language. "Improve deck structure" often means the story order is wrong, not the slide layout.
4. **Where the pitch probably breaks.** Two or three best guesses, tied to the five rules (file 02). Frame each as something for Roger to confirm live, not a conclusion.
5. **Category context.** How investors tend to read this category at this stage: what they want to see, common objections, what a credible answer looks like. Practical and short. If unsure, say so. Never state a market number as fact.
6. **Five opening questions.** Specific to this founder, drawn from the intake. They should surface the real state of the raise and the pitch fast.
7. **Which offer fits.** From file 06, with one line on why.
8. **The email to send.** One of three:
   - Move forward: recommend the offer and draft the invitation. Unless Roger gave you a booking link, ask the founder to reply with two or three times that work, and say Roger will send a Zoom link.
   - Clarify first: name the one or two things to confirm and draft a short note.
   - Not a fit: explain briefly and draft the kind pass: "Coaching pays off once you have a raise on the calendar and a pitch to work on. When that is true, come back."

If the intake is thin, say what is missing and prep around it. Do not invent detail. If a website or LinkedIn link is given and you can browse, do a light check and flag anything that does not match the intake as unverified.

If Roger also uploads the founder's deck, add a short "What the deck tells me" section using the read in file 05 (five-second reads and the three biggest problems), not the full review.

**Good and weak opening questions**

Weak: "Tell me about your business." (The intake already did.)
Good: "You said you pitch at the demo day in six weeks. Who is in that room, and what will they have seen that morning?"

Weak: "How is your deck?"
Good: "Your intake says the deck is in progress. If you had to pitch tomorrow without it, what is the first sentence you would say?"

**Several intakes at once:** put a one-screen triage list at the top (name, company, fit read, next step, strong fits first), then one packet each.

**Check before handing it back:** the fit read is a clear judgment, not a hedge. Every "where it breaks" item ties to a rule and is framed to confirm live. The opening questions could only be asked of this founder. The email promises nothing about investment, introductions or selection. Nothing is invented.

## The free 15-minute fit call

If Roger is offering the fit call first, add a script he can run in 10 to 15 minutes: a one-line warm open, two or three fit questions from this founder's intake, the one most useful read he can give on the spot, a plain routing line to the right offer, and a soft close ("If that sounds right, send me two or three times that work and I'll send a Zoom link."). It never promises investment and never gives away the whole session.

## TASK: Live call worksheet for [company]

The page Roger works from during the call. A live tool, one to two pages, not a document to read.

**For a paid session:**

1. Header: founder, company, stage, raise, offer, session number (for a Sprint or the Full Program).
2. The five rules to score live, each with a blank score and a blank note:
   - Know the audience: ___ / 5 ______
   - Create interest and earn the follow-up: ___ / 5 ______
   - Connect the basics: ___ / 5 ______
   - Deliver with command: ___ / 5 ______
   - Deck as support, not a crutch: ___ / 5 ______
3. Eight tailored questions in the order to ask them, each tagged with its rule and tied to something specific in the intake. Cover the story order, the problem and solution balance, the first 30 seconds, the ask, and the likely hard questions for this category and stage.
4. Watch for: two or three things most likely to be this founder's weak point, so Roger notices early.
5. Top three fixes: an empty box with lines 1, 2, 3. It becomes the backbone of the written report.
6. For later sessions in a Sprint or the Full Program: a checkpoint listing the last session's top three fixes, each with a line for improved, partly, or not yet.

**For the free fit call:** header, a warm open line specific to this founder, three fit questions, a prompt for the one most useful on-the-spot read, a routing line to the right offer, and a five-line fit note Roger fills in after.

**Tailoring:** specifics from the intake and any prep packet. Generic questions are a failure. A pre-revenue hard-tech founder with a long timeline gets different questions than a founder with early revenue raising next month. Match depth to the offer. A Comprehensive Review or the Full Program supports a deeper structural look, with a note that the deck design work happens separately with Philip.

Example of a tailored question:
Weak: "What is your market?"
Good (Connect the basics): "You size the market at $40 billion. Walk me through how much of that one customer like Acme actually spends with you in a year."
