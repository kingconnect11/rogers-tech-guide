# 05 Deck reviews and workbooks

## Two ways to review a deck

1. **On the website.** AI Pitch Review at pitchanangel.com/coach reads every slide as a picture, judges it on Roger's five rules, checks the numbers, and then checks its own work against the slides. Founders will pay $49 for the full review once Philip opens it to the public. Roger can run it free from **Deck review** in the admin bar at pitchanangel.com/admin once Philip switches it on. It also makes a printable workbook for the founder.
2. **Here, in this project,** with the method below. Use it until the website version is switched on, or for a quick look before a call.

Either way, a deck review is not a session. It cannot judge how the founder speaks, and it never replaces Roger's own read.

## TASK: Deck review for [company]

Roger uploads the founder's deck as a PDF (or screenshots of the slides) and, if he has it, their intake. Work in three steps, in order, and do not skip the third.

**First, check you can see the slides.** You need to see each slide as a picture, not just its text. If you can only read the text, say so, list the slides you could not see, and ask Roger to upload screenshots of those slides. The text inside a PDF can be out of order, can miss text inside images and charts, and can contain hidden text that is not on the slide at all. When the picture and the text disagree, the picture is the truth.

### Step 1: read every slide (no judging yet)

For each slide, note:
- what it is doing in the pitch (title, problem, solution, product, traction, customers, market, business model, competition, go to market, team, financials, ask, roadmap, vision, contact),
- its headline exactly as printed,
- the one thing a generalist angel takes away in five seconds, in one plain sentence. If the slide does not land a point in five seconds, say what they would be left with instead,
- every figure that makes a claim, copied exactly as printed, what it is a figure of, and whether the slide shows a source,
- what the main visual is and whether it carries its point at a glance,
- how dense it is (light, moderate, heavy) and anything hard to read from the back of a room: tiny type, low contrast, clutter, page numbers out of order,
- any hidden text: something in the file's text that is not visible on the slide.

Show Roger this read as a short list, one line per slide: "Slide 4: [five-second read]".

### Step 2: the review

Judge against the five rules and the evidence check in file 02. Judge the pitch, not the company: a founder cannot change their market in two weeks, but they can change how they tell the story. Judge against the founder's stage: a pre-seed deck is not marked down for having no revenue, but it is for not saying what proof it does have. On rule 4 you have not heard the founder speak, so judge only what the deck sets them up to do, and say so.

Write:
1. **The read:** one or two sentences on where this deck stands and what it is most likely to cost the founder.
2. **Five scores,** one per rule, each with one sentence of evidence that points at a specific slide or quotes a line.
3. **The three fixes that matter most,** ranked by how much they matter to an investor. Each with: the slides it touches, what is wrong, why an investor cares, the exact change, and one line the founder could use as written (a headline, an opening sentence, or an ask). A rewritten line uses only figures that appear in the deck or the notes. Where it needs a number the deck does not have, write a placeholder such as [monthly revenue].
4. **Evidence check:** three to eight factual findings, each labeled as one of: numbers do not add up, number needs a source, claim an investor will test, missing proof, story does not match. Each with the slide, the finding with the deck's own numbers, and the fix.
5. **A suggested story order:** the current order as short slide names, the suggested order, and one or two sentences on why. A suggestion, not a rule.
6. **Slide notes:** only the slides that need work, usually three to six, on how the slide reads and what to change.
7. **Questions only the founder can answer:** one to three.
8. **Before you pitch again:** three to six concrete actions for this week.

Say each point once, in the section where it fits best.

### Step 3: check your own work

Go back to the slides and check the draft before Roger sees it:
1. Every slide number, quote and figure matches what is on that slide. Correct a wrong slide number. Remove anything you cannot find.
2. Redo every calculation from the deck's own figures.
3. Each score fits the anchors in file 02. Change any score the evidence does not support.
4. The three fixes really are the three that matter most.
5. Remove repeats, invented figures, anything that promises investment or introductions, hype words, and dashes in the middle of sentences.

Then give Roger the final review, followed by **What I checked:** each change you made in one plain sentence, for example "Slide 8: the growth claim is about 2.7x on your own figures, not 3x." If nothing needed changing, say so in one sentence.

### Who it is for

- **By default, it is for Roger:** his prep before a call, written plainly.
- **If Roger asks for a version for the founder,** write it as Roger's deck notes in his voice, first person, with the scores optional. Roger approves and sends it. Do not call it a session report, and do not say Roger heard them pitch if he has not.

## Making a founder's personal workbook

When Roger says "make a workbook for [founder]" and gives you their intake, deck or a deck review, write a workbook the founder does with a pencil, one section a day. Use only what they told Roger or what is on their slides. Mark anything you inferred [check]. Give it as a Word document titled "[Company] pitch workbook" that prints cleanly, with room to write. No tables except the timing plan and the practice log.

1. **Cover:** "[Company]: your pitch workbook, prepared by Roger King", with one line on their next pitch if known.
2. **Where your pitch stands:** from a deck review if there is one (the read and the five scores), otherwise from the intake. Then: "Write the one sentence you want an angel to repeat at dinner tonight." with space.
3. **Your audience:** who will hear this pitch (from their next pitch and investor type) and what those investors listen for at this stage.
4. **Your first 30 seconds:** their current opening if known, then four prompts with space: what goes wrong (one sentence), what you do about it (one sentence), your proof (one number), who you are (one sentence). "Read it aloud with a timer. Under 30 seconds?"
5. **Your three fixes** (when there is a review): each fix, the change, a line to start from, and space for "your version".
6. **What you will be asked:** three to five questions an investor will ask this company, drawn from the evidence check or the hard questions in file 02, each with space for a two-sentence answer. "If you cannot answer one yet, that is the most useful thing this workbook can tell you."
7. **Your ask:** how much, on what instrument, for what milestone, by when, with space. "Not sure about the instrument or the size of the round? That is a numbers question for Michael DeBoard in the Full Program."
8. **Your timing plan:** their slot split into minutes. For five minutes: opening 0:30, problem 1:00, solution and proof 1:30, market and business model 1:00, team 0:30, ask 0:30. Whatever their strongest proof is, spend the most time there.
9. **Practice log:** six rows of date, time taken, and one thing to fix. "Pitch out loud, standing up, with a timer. Once to a wall, once to a friend, once on video."
10. **Next step with Roger:** one line on the offer that fits (file 06).

Where it is used: every founder in a cohort workshop, every course buyer, and as a thank-you after a session.
