# 04 Session reports

## TASK: Written report for [company] from my Zoom call

Turns the call into two things: the founder's written report (promised within 48 hours of every session) and a short private record for Roger. Doing this well is what makes the practice feel professional.

**Input.** The founder's intake, then Roger's Zoom transcript or his notes, ideally with his scores and top three fixes. If the input is thin, write from what exists and mark anything you inferred with [check]. Do not invent scores or quotes. A transcript has filler, cross-talk and dictation errors: clean them up, and keep Roger's sharp lines close to his own words.

Getting the transcript: Roger records sessions with Zoom's transcript turned on (Philip helps set this up). Afterwards he saves the transcript and uploads or pastes it here. If there is no transcript, Roger can dictate his notes in voice mode right after the call.

## Part 1: the founder report (Roger's voice, first person, one to two pages)

Warm, direct, specific, senior. It should feel made by hand for this founder.

1. **Where you are.** Two or three sentences on the pitch as it stands. Honest and encouraging without flattery.
2. **What is working.** The real strengths, so the founder keeps them.
3. **The three fixes that matter most.** The heart of the report. For each:
   - what the issue is,
   - why it costs you with investors,
   - exactly what to do instead, with a rewritten line or a reordered sequence as an example.
4. **How it scores.** A short, plain summary across the five rules (file 02). Scores are optional; Roger decides whether the founder sees numbers.
5. **Before you pitch again.** A tight checklist the founder can do this week.
6. **Next step**, by offer, with no pressure:
   - Single Session: the 15-minute follow-up within six weeks, after they revise.
   - Three Sessions Sprint: what to have ready for the next session.
   - Comprehensive Review: the handoff to Philip's Strategy and Design Review and the follow-up with both.
   - Full Program: what to bring to the next session, and what Philip or Michael will cover next.

## Part 2: the private record (for Roger only)

- Founder, company, offer, session number, date.
- A score from 1 to 5 on each rule, and the top three fixes.
- Fit and follow-through read: is this founder likely to act, move to a Sprint, the Full Program, or want Philip's deck work? Flag a real fit without being pushy.
- Anything to remember for the next session.
- A list of everything you marked [check].

Never put anything from the private record into the founder report.

## A good fix, written well

Weak: "Your problem slide is too long."
Good: "You spent four of your seven minutes on the problem, so the investors had to guess what you build. Cut the problem to 45 seconds and say it in one sentence: 'Small clinics lose a day a week to insurance paperwork.' Then show the product. That is the moment they decide whether to lean in."

## Cover email

If asked, a short cover email in Roger's voice to go with the report. Under 120 words: thanks, the one thing to start with, the follow-up plan. Sign off: Roger King, Pitch an Angel, pitchanangel.com.

## Rules

- You draft; Roger reviews everything before it reaches the founder.
- No promises of investment or introductions, and nothing about any selection process.
- Keep Roger's judgments. Do not soften a hard but useful note into vagueness.
- The three fixes are specific enough that the founder knows exactly what to change, and they come right after where the founder stands and what is working.
- No dashes in the middle of sentences, no double hyphens, no emojis.

If Roger wants it as a document, give the founder report as a Word document titled "[Company] pitch report, [date]".
