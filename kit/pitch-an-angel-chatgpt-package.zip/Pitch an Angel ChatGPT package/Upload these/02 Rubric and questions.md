# 02 Rubric and questions

Roger's five rules are the spine of every prep packet, worksheet, report and deck review. Score each rule from 1 to 5 with a one-line note. Reviews are honest: a 3 is a real 3. Most pitches a founder brings for coaching score 2 or 3 on most rules, and a 5 is rare.

Scale: 1 weak, 2 marginal, 3 solid, 4 strong, 5 ideal. A 2 or a 4 sits between the anchors on either side.

## The five rules

### 1. Know the audience
Does the pitch meet these investors where they are, at this stage, in this category, in plain language a generalist angel can follow, with an ask that room expects?
- **1 looks like:** written for insiders or for customers. Jargon a generalist cannot follow, or an ask that does not fit an angel room at this stage.
- **3 looks like:** mostly plain and the ask fits the stage, but a few slides or lines lean on internal terms or assume knowledge the room will not have.
- **5 looks like:** a generalist angel follows every point on first hearing, and the size, terms and milestones of the ask are what that room expects.

### 2. Create interest and earn the follow-up
Do the first 30 to 60 seconds make the problem and the answer clear, and does the strongest proof come early enough that an investor wants a second meeting? The win is the second meeting, not a check on the spot.
- **1 looks like:** after three minutes, or three slides, an investor still could not say what the company does, and the strongest proof is buried or missing.
- **3 looks like:** the opening is clear enough, but the best proof arrives late or is understated, so interest builds slowly.
- **5 looks like:** problem and answer land in the first 30 seconds, the strongest proof is up front, and it ends on a reason to meet again.

### 3. Connect the basics
Do problem, solution, proof, market, business model, team and ask connect into one story, with the problem and solution in balance and the ask tied to a milestone?
- **1 looks like:** basics missing or contradicting each other: a different customer or business from one part to the next, or an ask tied to nothing.
- **3 looks like:** the basics are there but loosely joined: one gap (no business model, no proof, an ask without a milestone) or too long on the problem.
- **5 looks like:** one customer, one business, one story from problem to ask, and the money buys a named milestone.

### 4. Deliver with command
Pacing, clarity, eye contact, composure under a hard question, and time. When judging from a deck alone, judge only what the deck sets the founder up to do.
- **1 looks like:** reads the slides, speeds up when nervous, gets defensive, runs out of time before the ask. On a deck: several ideas per slide and full sentences the founder will read aloud.
- **3 looks like:** mostly steady, with some reading, rushing or a shaky answer. On a deck: most slides carry one idea, a few are crowded or out of order.
- **5 looks like:** the founder leads the room, holds a pause, answers the hard question without flinching, finishes on time. On a deck: one idea per slide in a natural speaking order.

### 5. Deck as support, not a crutch
Does the deck support the founder or replace the founder? Content, legibility and flow only. Graphic design is Philip's work, not Roger's.
- **1 looks like:** walls of small text, unreadable charts, or slides that only repeat what will be said.
- **3 looks like:** legible overall, with a few dense or decorative slides that add little.
- **5 looks like:** every slide reads in five seconds from the back of a room and shows something words cannot: a number, a picture, a chart. Usually 12 to 14 slides at most.

## Roger's principles (ground every judgment in these)

- The whole purpose of a pitch is to generate interest and earn the next conversation, not to answer every question.
- Whatever your biggest bragging point is, spend the most time on it. Lead with the strongest proof: the pain, the product, the traction, the team, or the timing.
- Give the listener a simple frame first, such as "Airbnb for RV rentals". The frame is the door, not the whole story.
- The 30-second test: in the first 30 seconds, would an investor who knows nothing about this industry understand the problem, why it needs solving, and the solution? Roger's model: "A data center's single biggest cost is energy. Our system saves 2 to 8 percent on the energy bill every month."
- The most common mistake in a fixed-time pitch: too long on the problem, not enough on the solution. Founders live and breathe the idea. The audience has no idea what it is.
- Investors love revenue. A real number beats a forecast.
- A deck is like a resume. You do not get the job by emailing it. You earn the interview.
- "Some guys just read the slides. We can all read. I want something more than that."
- Save accomplishments for the team part, after the investor is already interested, unless the team is the strongest proof.
- The ask says what the money buys and how far it goes.
- A useful default order: simple frame, pain or opportunity, solution, proof, market and business model, team, ask. The order can change. Strongest proof near the front should not.
- Networking is step by step. The first goal is the next conversation: contact details and permission to follow up. Do not sell on the spot.

## The evidence check (for numbers and claims)

The rules judge how the pitch lands. The evidence check is a close, factual read of what the founder actually claims.

- Every number needs a clear referent. "40% faster" means nothing until it says faster than what, measured how.
- Inputs need a source. Market sizes, prices and percentages the founder did not derive should say where they came from.
- Do the arithmetic with the founder's own figures: totals, growth multiples, market math, use of funds that should add to 100 percent. Show the numbers.
- Flag claims an investor will test ("the first platform", "patented", "proprietary data") and say what would back them up.
- A giant top-line market with no path to what the company can serve works against the founder.
- Watch for a story that changes from one part to the next: a different customer, a different business (services versus software), a different description of the company.
- Missing proof: no product shown, no customer evidence, no milestone tied to the ask.
- Never invent market figures. Coach the founder to source their own.

## The first three skeptical questions

For every company, name the first three skeptical questions an investor will ask, and check whether the pitch answers them before they are asked. This is the single most useful lens.

## Hard questions every founder should be ready for

- Why you, and why now?
- What happens to this business if a well-funded incumbent copies you?
- What is the real reason someone churns or says no?
- What do you know about this market that most people do not?
- What are you going to do with the money, and what milestone does it buy?
- What has to be true for this to be a large outcome?

## Question set: the free 15-minute fit call

Purpose: confirm fit, understand the raise, build trust, point to the right offer. Not a coaching session.
- Tell me in a sentence or two what you are building and who it is for.
- Where are you in the raise, and what is the next moment you are pitching for?
- Have you pitched this to investors yet? What happened?
- What do you think is not landing?
- What would make a session a win for you?
- Give one real, specific read on the spot. Enough to show the value, not the whole session.
- Route: "Based on where you are, here is where I would start, and why."

## Question set: a coaching session

**Know the audience**
- Who is the specific investor or room this pitch is built for, and what do they care about at your stage?
- If a generalist and a domain expert were both in the room, who did you write this for?

**Create interest and earn the follow-up**
- Walk me through your first 30 seconds exactly as you would deliver them.
- If I only remembered one sentence from your pitch, which one do you want it to be?
- What is the single reason an investor should want a second meeting?

**Connect the basics**
- In one line each: the problem, the solution, the market, and why now.
- Where does the pitch spend most of its time, the problem or the solution? Why?
- What is the ask, and what does the money get you to?

**Deliver with command**
- Deliver the hardest 90 seconds of your pitch and let me push back mid-stream.
- Which investor question do you dread most? Let's take it now.
- How are you managing time? What gets cut if you have five minutes instead of ten?

**Deck as support, not a crutch**
- Can you make each key point without reading the slide?
- Which slide are you hiding behind, and what would you say if it were gone?

**Close**
- The three highest-leverage changes before you pitch again are: 1, 2, 3.
- What will you have changed by our next check-in?
